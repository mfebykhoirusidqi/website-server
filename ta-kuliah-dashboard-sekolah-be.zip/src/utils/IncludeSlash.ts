const cekNama = (username: any) => {
  return username.includes("/");
};

export default cekNama;
