export enum Role {
  Admin = "admin",
  Guru = "guru",
  Siswa = "siswa",
}
